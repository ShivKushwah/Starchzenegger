package kiloboltgame;

import java.awt.Rectangle;
import java.util.ArrayList;

import kiloboltgame.StartingClass.GameState;

public class Enemy {

	private int power, speedX, centerX, centerY;
	public static double robotHealth = 1000;
	private Background bg = StartingClass.getBg1();

	public Rectangle r = new Rectangle(0,0,0,0);
	public int health = 5;
	public int countDown = 0;
	private ArrayList<EnemyProjectile> projectiles = new ArrayList<EnemyProjectile>();

	// Behavioral Methods
	public void update() {
		follow();
		countDown++;
		if (countDown >= 100)
		{
			countDown = 0;
			attack();
		}
		centerX += speedX;
		speedX = bg.getSpeedX()*5;
		r.setBounds(centerX - 25, centerY-25, 50, 60);
	//	if (StartingClass.b.destroy.intersects(r))
	//	{
	//		StartingClass hb = 
	//	}
		if (r.intersects(Robot.yellowRed)){
			checkCollision();
		}
		
	}

public void follow() {
	long timer2 = System.currentTimeMillis();
	
//	if (System.currentTimeMillis() - StartingClass.timer >= 2000)
	if (centerX < -95 || centerX > 810){
		centerX = 809;
 	}

	else if (Math.abs(StartingClass.robot.getCenterX() - centerX) < 5) {
		//movementSpeed = 0;
	}

	else {

		if (StartingClass.robot.getCenterX() >= centerX) {
			centerX += 3;
		} else {
			centerX -= 3;
		}

		if (StartingClass.robot.getCenterY() >= centerY) {
			centerY += 3;
		} else {
			centerY -= 3;
		}
	}

	}


	private void checkCollision() {
		if (r.intersects(Robot.rect) || r.intersects(Robot.rect2) || r.intersects(Robot.rect3) || r.intersects(Robot.rect4)){
			//System.out.println("collision");
			robotHealth--;
			//System.out.println(robotHealth);
			//StartingClass.robot = null;
			if(Enemy.robotHealth == 0)
			StartingClass.state = GameState.Dead;
			}
		}

	public void die() {

	}

	public void attack() {
		EnemyProjectile p = new EnemyProjectile(centerX - 50, centerY);
		projectiles.add(p);
	}

	public int getPower() {
		return power;
	}

	public int getSpeedX() {
		return speedX;
	}

	public int getCenterX() {
		return centerX;
	}

	public int getCenterY() {
		return centerY;
	}

	public Background getBg() {
		return bg;
	}



	public void setPower(int power) {
		this.power = power;
	}

	public void setSpeedX(int speedX) {
		this.speedX = speedX;
	}

	public void setCenterX(int centerX) {
		this.centerX = centerX;
	}

	public void setCenterY(int centerY) {
		this.centerY = centerY;
	}
	public ArrayList<EnemyProjectile> getProjectile() {
		return projectiles;
	}


	public void setBg(Background bg) {
		this.bg = bg;
	}

	
}
