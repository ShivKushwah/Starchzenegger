package kiloboltgame;


public class Beer extends PowUp
{
	
	
	
	public Beer(int lX, int lY)
	{
		super(lX, lY, 0, 0);
		//draw stuff in starting class
		hellLoose();
	}

}