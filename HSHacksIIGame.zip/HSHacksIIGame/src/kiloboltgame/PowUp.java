package kiloboltgame;



import java.awt.Rectangle;

public class PowUp
{
	private int healthUp;
	private int speedUp;
	public Rectangle powerBounds, destroy;
	private int speedX, centerX, centerY;
	
	StartingClass beerEdit = new StartingClass();


	public PowUp(int lX, int lY, int addHealth, int addSpeed)
	{
		powerBounds = new Rectangle(lX, lY, 50, 60);
		
		centerX = lX;
		centerY = lY;
		
		healthUp = addHealth;
		speedUp = addSpeed;

	}


	public void addHealth()
	{
		Enemy.robotHealth += healthUp;
		System.out.println("Health Up is working");
		
	}

	public void addSpeed()
	{
		StartingClass.robot.setSpeedX(StartingClass.robot.getSpeedX() + speedUp);
		
	}


/** if you touch projectile, all enemies on screen die
*/
	public void hellLoose()
	{

		if (Robot.rect.intersects(powerBounds) || Robot.rect2.intersects(powerBounds) || 
					Robot.rect3.intersects(powerBounds) || Robot.rect4.intersects(powerBounds))
		{
			 beerEdit.beerDisappear();		//make it so that if enemy touches destroy, they disappear
			 
			 long timer = System.currentTimeMillis();
			 destroy = new Rectangle(StartingClass.robot.getCenterX() - 35, StartingClass.robot.getCenterY() - 40, 800, 480); 	
			 
			 
			 if (System.currentTimeMillis() - timer >= 30000)
			 {
			 	try
			 	{
			 		destroy = null;
			 	}
			 	catch (Exception a)
			 	{
			 		System.out.println("The code is still working...");
			 	}
			 	finally
			 	{
			 		System.out.println("You're a little fucker");
			 	}
			 }
			 
		}

	}
	
	public void update() {
		centerX += speedX;
		speedX = StartingClass.getBg1().getSpeedX()*5;
		powerBounds.setBounds(centerX - 25, centerY-25, 50, 60);
		
	}
	
	public int getX()
	{
		return centerX;
	}
	
	public int getY()
	{
		return centerY;
	}

}