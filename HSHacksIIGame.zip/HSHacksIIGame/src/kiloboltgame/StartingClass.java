package kiloboltgame;

import java.applet.Applet;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.lang.Math;

import kiloboltgame.framework.Animation;

public class StartingClass extends Applet implements Runnable, KeyListener {

	enum GameState {
		Running, Dead
	}

	static GameState state = GameState.Running;

	public static Robot robot;
	public static int jumpCount = 0;
	public static Heliboy hb, hb2;
	
	//HSHACKS AUSTIN TAKE HOME *****************************************************************************************
	public static Beer b;
	public static Speed sbottle;
	public static Jugg jnogg;
   	
	
	
	public static int score = 0;
	private Font font = new Font(null, Font.BOLD, 30);
	public static double robotHealthPer = 0;

	private Image image, currentSprite, character, character2, character3,
			characterDown, characterJumped, background, heliboy, heliboy2,
			heliboy3, heliboy4, heliboy5, 
			//HSHACKS AUSTIN TAKE HOME *****************************************************************************************
			beer, jugg, speed, proj, eProj;

	public static Image tilegrassTop, tilegrassBot, tilegrassLeft,
			tilegrassRight, tiledirt;
	
    public static long timer = System.currentTimeMillis();
	private Graphics second;
	public URL base;
	private static Background bg1, bg2;
	private Animation anim, hanim;
	
	

	private ArrayList<Tile> tilearray = new ArrayList<Tile>();

	@Override
	public void init() {

		setSize(800, 480);
		setBackground(Color.BLACK);
		setFocusable(true);
		addKeyListener(this);
		Frame frame = (Frame) this.getParent().getParent();
		frame.setTitle("Q-Bot Alpha");
		try {
			base = getDocumentBase();
		} catch (Exception e) {
			// TODO: handle exception
		}


		// Image Setups
		character = getImage(base, "data/maincharsT.png");
		character2 = getImage(base, "data/maincharsT.png");
		character3 = getImage(base, "data/maincharsT.png");
		
		proj = getImage(base, "data/missileT.png");
		eProj = getImage(base, "data/missileT.png");
		characterDown = getImage(base, "data/maincharsT.png");
		characterJumped = getImage(base, "data/maincharsT.png");

		heliboy = getImage(base, "data/fatEnemyT.png");
		heliboy2 = heliboy;
		heliboy3 = heliboy;
		heliboy4 = heliboy;
		heliboy5 = heliboy;


		background = getImage(base, "data/background.png");

		tiledirt = getImage(base, "data/tiledirt.png");
		tilegrassTop = getImage(base, "data/tilegrasstop.png");
		tilegrassBot = getImage(base, "data/tilegrassbot.png");
		tilegrassLeft = getImage(base, "data/tilegrassleft.png");
		tilegrassRight = getImage(base, "data/tilegrassright.png");
		
		
		//HSHACKS AUSTIN TAKE HOME ***********************************************************************************************

		beer = getImage(base, "data/beerup.png");
		jugg = getImage(base, "data/beerup.png");
		speed = getImage(base, "data/beerup.png");
		
		

		anim = new Animation();
		anim.addFrame(character, 1250);
		anim.addFrame(character2, 50);
		anim.addFrame(character3, 50);
		anim.addFrame(character2, 50);

		hanim = new Animation();
		hanim.addFrame(heliboy, 100);
		hanim.addFrame(heliboy2, 100);
		hanim.addFrame(heliboy3, 100);
		hanim.addFrame(heliboy4, 100);
		hanim.addFrame(heliboy5, 100);
		hanim.addFrame(heliboy4, 100);
		hanim.addFrame(heliboy3, 100);
		hanim.addFrame(heliboy2, 100);

		currentSprite = anim.getImage();
	}

	@Override
	public void start() {
		bg1 = new Background(0, 0);
		bg2 = new Background(2160, 0);
		robot = new Robot();
		// Initialize Tiles
		try {
			loadMap("data/map1.txt");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		//HSHACKS AUSTIN TAKE HOME *****************************************************************************************
		b = new Beer((int)(Math.random()*200 + 3200), (int)(Math.random()*400 + 40));
		sbottle = new Speed((int)(Math.random()*200 + 3200), (int)(Math.random()*400 + 40),(int)(Math.random()*100));
		jnogg = new Jugg((int)(Math.random()*200 + 3200), (int)(Math.random()*400 + 40),(int)(Math.random()*100));
		hb = new  Heliboy(340, 360);
		hb2 = new Heliboy(700, 200);
		

		Thread thread = new Thread(this);
		thread.start();
	}

	private void loadMap(String filename) throws IOException {
		ArrayList lines = new ArrayList();
		int width = 0;
		int height = 0;

		BufferedReader reader = new BufferedReader(new FileReader(filename));
		while (true) {
			String line = reader.readLine();
			// no more lines to read
			if (line == null) {
				reader.close();
				break;
			}

			if (!line.startsWith("!")) {
				lines.add(line);
				width = Math.max(width, line.length());

			}
		}
		height = lines.size();

		for (int j = 0; j < 12; j++) {
			String line = (String) lines.get(j);
			for (int i = 0; i < width; i++) {

				if (i < line.length()) {
					char ch = line.charAt(i);
					Tile t = new Tile(i, j, Character.getNumericValue(ch));
					tilearray.add(t);
				}

			}
		}

	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
	}

	@Override
	public void run() {
		if (state == GameState.Running) {

		while (true) {
		//	try{
			robot.update();
			robotHealthPer = Enemy.robotHealth/10; 
			//System.out.println(robotHealthPer);
			/*if (robot.getCenterY() == 377)
				jumpCount = 0;*/
			
			//
			//} catch (NullPointerException e) {
				 //robot = new Robot();
				//state = GameState.Dead;
			//	 robot = new Robot();
		//	}
			if (robot.isJumped()) {
				currentSprite = characterJumped;
			} else if (robot.isJumped() == false && robot.isDucked() == false) {
				currentSprite = anim.getImage();
			}

			ArrayList projectiles = robot.getProjectiles();
			for (int i = 0; i < projectiles.size(); i++) {
				Projectile p = (Projectile) projectiles.get(i);
				if (p.isVisible() == true) {
					p.update();
				} else {
					projectiles.remove(i);
				}
			}
			ArrayList projectilesE1 = hb.getProjectile();
			for (int i = 0; i < projectilesE1.size(); i++) {
				EnemyProjectile p = (EnemyProjectile) projectilesE1.get(i);
				if (p.isVisible() == true) {
					p.update();
				} else {
					//System.out.println(i);
					//System.out.println(pro);

					projectilesE1.remove(i);
				}
			}

			updateTiles();
			hb.update();
			hb2.update();
			bg1.update();
			bg2.update();
			
			//HSHACKS AUSTIN TAKE HOME *****************************************************************************************
			b.update();
			sbottle.update();
			jnogg.update();
			
			
			
			animate();
			repaint();
			try {
				Thread.sleep(17);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (robot.getCenterY() > 500) {
				state = GameState.Dead;
			}
		}}
	}

	public void animate() {
		anim.update(10);
		hanim.update(50);
	}

	@Override
	public void update(Graphics g) {
		if (image == null) {
			image = createImage(this.getWidth(), this.getHeight());
			second = image.getGraphics();
		}

		second.setColor(getBackground());
		second.fillRect(0, 0, getWidth(), getHeight());
		second.setColor(getForeground());
		paint(second);

		g.drawImage(image, 0, 0, this);
		


	}

	@Override
	public void paint(Graphics g) {
		
		if (state == GameState.Running) {

		g.drawImage(background, bg1.getBgX(), bg1.getBgY(), this);
		g.drawImage(background, bg2.getBgX(), bg2.getBgY(), this);
		paintTiles(g);

		ArrayList projectiles = robot.getProjectiles();
		for (int i = 0; i < projectiles.size(); i++) {
			Projectile p = (Projectile) projectiles.get(i);
			g.drawImage(proj, p.getX(), p.getY(), this);
			//g.setColor(Color.YELLOW);
			//g.fillRect(p.getX(), p.getY(), 10, 5);
		}
		ArrayList projectilesE1 = hb.getProjectile();
		for (int i = 0; i < projectilesE1.size(); i++) {
			EnemyProjectile p = (EnemyProjectile) projectilesE1.get(i);
			g.drawImage(eProj, p.getX(), p.getY(), this);
			//g.setColor(Color.YELLOW);
			//g.fillRect(p.getX(), p.getY(), 100, 5);//100,  5
		}

		g.drawImage(currentSprite, robot.getCenterX() - 61,
				robot.getCenterY() - 63, this);
		g.drawImage(hanim.getImage(), hb.getCenterX() - 48,
				hb.getCenterY() - 48, this);
		g.drawImage(hanim.getImage(), hb2.getCenterX() - 48,
				hb2.getCenterY() - 48, this);
		g.setFont(font);
		g.setColor(Color.WHITE);
		g.drawString(Integer.toString(score), 740, 30);
		g.drawString(Double.toString(robotHealthPer), 500, 30);
		
		//HSHACKS AUSTIN NIGHT ****************************************************************************************
		g.drawImage(beer, b.getX(), b.getY(), this);
		g.drawImage(speed, sbottle.getX(), sbottle.getY(),this);
		g.drawImage(jugg,jnogg.getX(),jnogg.getY(),this);
		

		
	} else if (state == GameState.Dead) {
		g.setColor(Color.BLACK);
		g.fillRect(0, 0, 800, 480);
		g.setColor(Color.WHITE);
		g.drawString("Dead", 360, 240);


	}
	}

	private void updateTiles() {

		for (int i = 0; i < tilearray.size(); i++) {
			Tile t = (Tile) tilearray.get(i);
			t.update();
		}

	}

	private void paintTiles(Graphics g) {
		for (int i = 0; i < tilearray.size(); i++) {
			Tile t = (Tile) tilearray.get(i);
			g.drawImage(t.getTileImage(), t.getTileX(), t.getTileY(), this);
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {

		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			System.out.println("Move up");
			break;

		case KeyEvent.VK_DOWN:
			currentSprite = characterDown;
			if (robot.isJumped() == false) {
				robot.setDucked(true);
				robot.setSpeedX(0);
			}
			break;

		case KeyEvent.VK_LEFT:
			robot.moveLeft();
			robot.setMovingLeft(true);
			break;

		case KeyEvent.VK_RIGHT:
			robot.moveRight();
			robot.setMovingRight(true);
			break;

		case KeyEvent.VK_SPACE:
			if(jumpCount < 2) robot.jump();
			//jumpCount++;
			break;

		case KeyEvent.VK_CONTROL:
			if (robot.isDucked() == false && robot.isJumped() == false
					&& robot.isReadyToFire()) {
				robot.shoot();
				robot.setReadyToFire(false);
			}
			break;

		}

	}

	@Override
	public void keyReleased(KeyEvent e) {
		switch (e.getKeyCode()) {
		case KeyEvent.VK_UP:
			System.out.println("Stop moving up");
			break;

		case KeyEvent.VK_DOWN:
			currentSprite = anim.getImage();
			robot.setDucked(false);
			break;

		case KeyEvent.VK_LEFT:
			robot.stopLeft();
			break;

		case KeyEvent.VK_RIGHT:
			robot.stopRight();
			break;

		case KeyEvent.VK_SPACE:
			//jumpCount--;
			
			break;

		case KeyEvent.VK_CONTROL:
			robot.setReadyToFire(true);
			break;

		}

	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub

	}

	public static Background getBg1() {
		return bg1;
	}

	public static Background getBg2() {
		return bg2;
	}

	public static Robot getRobot() {
		return robot;
	}

	public void beerDisappear()
	{
		beer = getImage(base, "data/delete.png");
		try
	 	{
	 		b = null;
	 	}
	 	catch (Exception a)
	 	{
	 		System.out.println("Ur a fuckboi");
	 	}
		
		b = new Beer((int)(robot.getCenterX() + Math.random()*200 + 3200), (int)(robot.getCenterY()+ Math.random()*400 + 40));
	}
	
}