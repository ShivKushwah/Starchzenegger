package kiloboltgame;

import java.awt.Rectangle;

import kiloboltgame.StartingClass.GameState;

public class EnemyProjectile {

	private int x, y, speedX;
	private int speed = 1;
	private int destX, destY;
	private int deathCount = 10; //-1000
	
	private boolean visible;
	
	private Rectangle r;
	
	public EnemyProjectile(int startX, int startY) {

		x = startX;
		y = startY;
		speedX = speed;
		visible = true;
		
		r = new Rectangle(0, 0, 0, 0);
	}
	
	public void update() {
		//speedX -= StartingClass.robot.speedX;
		destX = StartingClass.robot.getCenterX();
		destY = StartingClass.robot.getCenterY();
		r.setBounds(x,y,100,5);//10,5

		if (destX >= x) {
			x += speed;
		} else {
			x -= speed;
		}

		if (destY >= y) {
			y += 3;
		} else {
			y -= 3;
		}
       deathCount--;
       if (deathCount == 0)
       {
    	 visible = false;  
       
       }
		checkCollision();
	}

	private void checkCollision() {
		if (r.intersects(Robot.rect) || r.intersects(Robot.rect2) || r.intersects(Robot.rect3) || r.intersects(Robot.rect4)){
			visible = false;
			if (StartingClass.hb.robotHealth > 0) {
				StartingClass.hb.robotHealth -= 200;
 			}
			if(StartingClass.hb.robotHealth <= 0) StartingClass.state = GameState.Dead;
		}
}
	


	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getSpeedX() {
		return speedX;
	}

	public boolean isVisible() {
		return visible;
	}

	public void setX(int x) {
		this.x = x;
	}

	public void setY(int y) {
		this.y = y;
	}

	public void setSpeedX(int speedX) {
		this.speedX = speedX;
	}

	public void setVisible(boolean visible) {
		this.visible = visible;
	}
	
	
}
