package kiloboltgame;





import kiloboltgame.framework.Animation;

public class Speed extends PowUp
{
	

	
	public Speed(int lX, int lY, int addSpeed)
	{
		
		super(lX, lY, 0, addSpeed);
		//draw stuff in starting class
		if (Robot.rect.intersects(powerBounds) || Robot.rect2.intersects(powerBounds) || 
				Robot.rect3.intersects(powerBounds) || Robot.rect4.intersects(powerBounds))
		{
			addSpeed();
		}
		
	}


}