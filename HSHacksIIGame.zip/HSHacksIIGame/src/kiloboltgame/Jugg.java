package kiloboltgame;


public class Jugg extends PowUp
{
	
	
	public Jugg(int lX, int lY, int addHealth)
	{
		super(lX, lY, addHealth, 0);
		//draw stuff in starting class
		if (Robot.rect.intersects(powerBounds) || Robot.rect2.intersects(powerBounds) || 
				Robot.rect3.intersects(powerBounds) || Robot.rect4.intersects(powerBounds))
		{
			super.addHealth();
		}
		
	}

}